import { useNavigation } from 'expo-router';
import { View, Text, Image, Animated } from 'react-native';
import { useEffect, useState } from 'react';

const SplashScreen = () => {
  const [fadeAnim] = useState(new Animated.Value(0)); 
  const navigation = useNavigation();

  useEffect(() => {
    // Start the fade-in animation
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();

    // Navigate to the home screen after 3 seconds
    const timer = setTimeout(() => {
      navigation.replace('HomeScreen');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View className="flex-1 justify-center items-center relative bg-white">
      {/* Background Image */}
      <Image
        source={require('../assets/images/fish-background.webp')} 
        className="absolute top-0 left-0 right-0 bottom-0 w-full h-full opacity-50"
      />

      {/* Logo*/}
      <Animated.View style={{ opacity: fadeAnim }} className="mb-2">
        <Image
          source={require('../assets/images/logo.png')}
          style={{ width: 160, height: 192, resizeMode: 'contain' }}
        />
      </Animated.View>

      <Animated.View style={{ opacity: fadeAnim }}>
        <Text className="text-blue-600 text-sm mt-5">
          Loading...
        </Text>
      </Animated.View>
    </View>
  );
};

export default SplashScreen;
