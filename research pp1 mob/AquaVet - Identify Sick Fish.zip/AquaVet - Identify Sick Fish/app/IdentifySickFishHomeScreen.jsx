import React from "react";
import { View, Text, TouchableOpacity, Image, SafeAreaView, ScrollView } from "react-native";
import { Svg, Path, Defs, LinearGradient, Stop } from "react-native-svg";  
import { useNavigation } from "@react-navigation/native";
import { MaterialIcons, FontAwesome } from "@expo/vector-icons";

const IdentifySickFishHomeScreen = () => {
  
  const navigation = useNavigation();

  const fishStatus = {
    isHealthy: false,
    label: "Sick", 
    icon: "error", 
    color: "red", 
  };

  const handleSeeIllness = () => {
    navigation.navigate('IllnessIdentify'); 
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-200">
      {/* Main Container */}
      <View className="flex-1 relative">
        {/* Full-Screen Blue Header Section */}
        <View className="bg-blue-700 h-40 p-5 pb-8 mb-2 relative z-10">

          {/* Header*/}
          <View className="flex-row items-center">
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <MaterialIcons name="arrow-back" size={28} color="white" />
            </TouchableOpacity>
            <View className="ml-3">
              <Text className="text-white text-2xl font-bold">Identify Sick Fish</Text>
            </View>
          </View>

        </View>

        {/* Main Content */}
        <ScrollView
          className="flex-1 rounded-t-3xl -mt-28 p-5 relative z-10"
          contentContainerStyle={{ paddingBottom: 120 }}
        >
          {/*Image */}
          <View className="items-center mb-5">
            <Image
              source={{
                uri: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Gold_fish1.jpg/440px-Gold_fish1.jpg",
              }}
              style={{
                width: "100%",
                height: 200,
                borderRadius: 10,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.2,
                shadowRadius: 3,
                elevation: 5,
              }}
              resizeMode="cover"
            />
          </View>

          {/* Fish Details */}
          <View className="px-4 bg-white rounded-xl p-4 shadow-md">
            <View className="flex-row items-center justify-between">

              {/* Fish Name Section */}
              <View className="flex-1 items-center">
                <Text className="text-blue-700 text-2xl font-bold text-center">Goldfish</Text>
                <Text className="text-gray-500 text-lg font-semibold italic text-center">
                  Carassius auratus
                </Text>
              </View>

              {/* Vertical Divider */}
              <View className="w-[1px] h-full bg-gray-300 mx-4" />

              {/* Status Section */}
              <View className="flex-1 items-center">
                <Text className="text-blue-700 text-lg font-semibold mb-1">Status:</Text>
                <View className="flex-row items-center">
                  <MaterialIcons
                    name={fishStatus.icon}
                    size={20}
                    color={fishStatus.color}
                  />
                  <Text className={`text-${fishStatus.color}-600 text-lg font-bold ml-2`}>
                    {fishStatus.label}
                  </Text>
                </View>
              </View>
            </View>

            <Text className="text-gray-600 text-base leading-6 mt-4">
              The goldfish <Text className="font-semibold italic">(Carassius auratus)</Text> is a freshwater fish in the family Cyprinidae of
              order Cypriniformes. It is commonly kept as a pet in indoor aquariums and is one of
              the most popular aquarium fish.
            </Text>
            <Text className="text-gray-600 text-base leading-6 mt-2">
              Goldfish released into the wild have become an invasive pest in parts of North America
              and Australia.
            </Text>
            
            {/*Illness Button */}
            <View className="items-center mt-6">
              <TouchableOpacity
                onPress={handleSeeIllness}
                className="bg-blue-600 to-blue-500 w-full text-center py-3 px-8 rounded-lg shadow-lg shadow-blue-500/50 flex-row justify-center items-center"
              >
                <MaterialIcons name="visibility" size={24} color="white" />
                <Text className="text-white text-xl font-bold ml-3">See Illness Details</Text>
              </TouchableOpacity>
            </View>
          </View>



          {/* Common Illnesses Section */}
          <View className="mt-5 p-4 bg-white rounded-xl shadow-md">
            <Text className="text-blue-700 text-xl font-bold mb-3">
              <FontAwesome name="medkit" size={20} color="#1c4ed8" /> Common Illnesses
            </Text>
            <View className="bg-gray-100 p-4 rounded-lg shadow-sm">
              <Text className="text-gray-700 mb-2">• Ich (white spot disease)</Text>
              <Text className="text-gray-700 mb-2">• Fin rot</Text>
              <Text className="text-gray-700 mb-2">• Swim bladder disorder</Text>
              <Text className="text-gray-700 mb-2">• Fungal infections</Text>
              <Text className="text-gray-700 mb-2">• Velvet disease</Text>
            </View>
          </View>
        </ScrollView>

        {/* Waves Section*/}
        <View className="absolute bottom-0 left-0 right-0 z-0">
          <Svg height="100" width="100%" viewBox="0 0 1440 320">
            <Defs>
              <LinearGradient id="gradientWave" x1="0%" y1="0%" x2="100%" y2="0%">
                <Stop offset="0%" stopColor="#1c4ed8" />
                <Stop offset="100%" stopColor="#0565c5" />
              </LinearGradient>
            </Defs>
            <Path
              fill="url(#gradientWave)"
              d="M0,64L60,74.7C120,85,240,107,360,122.7C480,139,600,149,720,138.7C840,128,960,96,1080,74.7C1200,53,1320,43,1380,37.3L1440,32L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"
            />
          </Svg>
        </View>

      </View>
    </SafeAreaView>
  );
};

export default IdentifySickFishHomeScreen;
