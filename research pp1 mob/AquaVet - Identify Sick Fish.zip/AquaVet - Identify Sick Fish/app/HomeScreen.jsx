import React from 'react';
import { View, Text, TouchableOpacity, Image, SafeAreaView } from 'react-native';
import { Svg, Path, Defs, LinearGradient, Stop } from "react-native-svg";  
import { useNavigation } from 'expo-router'; 

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView className="flex-1 bg-gray-200">
      
      {/* Header Section */}
      <View className="bg-blue-700 h-1/3 p-5 rounded-b-3xl">
        {/* Header Icons */}
        <View className="flex-row items-center">
          <Image
            source={require('../assets/images/logo.png')}
            style={{ width: 40, height: 40, borderRadius: 40 }}
          />
          <View className="ml-2 justify-center">
            <Text className="text-white text-2xl font-bold">AquaVet</Text>
          </View>
        </View>

        {/* Logo */}
        <View className="items-center mt-5">
          <Text className="text-white text-2xl font-bold">Welcome!</Text>
          <Text className="text-white text-sm italic">Keeping Your Fish Happy and Healthy</Text>
        </View>
      </View>

      <View className="flex-1 bg-gray-200 rounded-t-3xl -mt-40 p-5 shadow-lg">
        <View className="flex-row flex-wrap justify-between mt-5">
          {/* Updated Buttons */}
          <MenuItem
            icon={require('../assets/images/icons/hygiene.png')}
            label="Identify Sick Fish"
            navigationTarget="SickFishSelectImageScreen"
            navigation={navigation} 
          />
          <MenuItem
            icon={require('../assets/images/icons/fish.png')}
            label="Fish Disease Diagnosis"
            navigationTarget="FishDiseaseDiagnosisHomeScreen" 
            navigation={navigation} 
          />
        </View>
      </View>

      {/* Waves Section*/}
      <View className="absolute bottom-0 left-0 right-0 z-0">
        <Svg height="100" width="100%" viewBox="0 0 1440 320">
          <Defs>
            <LinearGradient id="gradientWave" x1="0%" y1="0%" x2="100%" y2="0%">
              <Stop offset="0%" stopColor="#1c4ed8" />
              <Stop offset="100%" stopColor="#0565c5" />
            </LinearGradient>
          </Defs>
          <Path
            fill="url(#gradientWave)"
            d="M0,64L60,74.7C120,85,240,107,360,122.7C480,139,600,149,720,138.7C840,128,960,96,1080,74.7C1200,53,1320,43,1380,37.3L1440,32L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"
          />
        </Svg>
      </View>
    </SafeAreaView>
  );
};

// Menu Item Component
const MenuItem = ({ icon, label, navigationTarget, navigation }) => (
  <TouchableOpacity
    className="w-1/2 p-3"
    onPress={() => navigation.navigate(navigationTarget)} 
  >
    <View
      className="bg-white rounded-xl p-5 items-center justify-center"
      style={{
        shadowColor: '#4A90E2',
        shadowOffset: { width: 0, height: 5 },
        shadowOpacity: 0.3,
        shadowRadius: 10,
        elevation: 5,
        height: 120,
      }}
    >

      <Image
        source={icon}
        style={{ width: 50, height: 50 }}
        resizeMode="contain"
      />
      <Text className="text-gray-700 mt-3 text-center">{label}</Text>
    </View>
  </TouchableOpacity>
);

export default HomeScreen;
