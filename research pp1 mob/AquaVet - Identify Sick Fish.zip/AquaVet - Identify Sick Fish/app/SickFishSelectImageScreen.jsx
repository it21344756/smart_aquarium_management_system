import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { Svg, Path, Defs, LinearGradient, Stop } from 'react-native-svg';
import { useNavigation } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { MaterialIcons, FontAwesome5, FontAwesome, Ionicons } from '@expo/vector-icons';

const SelectImageScreen = () => {
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false); 
  const navigation = useNavigation();

  const pickImage = async () => {
    setLoading(true);
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      alert('Permission to access the gallery is required!');
      setLoading(false);
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
      allowsEditing: true,
      aspect: [4, 3],
    });

    setLoading(false);
    if (result.assets && result.assets.length > 0) {
      setImage(result.assets[0].uri);
    }
  };

  const captureImage = async () => {
    setLoading(true);
    const permissionResult = await ImagePicker.requestCameraPermissionsAsync();
    if (!permissionResult.granted) {
      alert('Permission to access the camera is required!');
      setLoading(false);
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      quality: 1,
      aspect: [4, 3],
    });

    setLoading(false);
    if (result.assets && result.assets.length > 0) {
      setImage(result.assets[0].uri);
    }
  };

  const handleSubmit = () => {
    if (image) {
      navigation.navigate('IdentifySickFishHomeScreen');
    } else {
      alert('Please select or capture an image first!');
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-200">
      <View className="flex-1 relative">

        {/*Header Section */}
        <View className="bg-blue-700 h-44 p-5 pb-8 mb-2 relative z-10">
          <View className="flex-row items-center">
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <MaterialIcons name="arrow-back" size={28} color="white" />
            </TouchableOpacity>
            <View className="ml-3">
              <Text className="text-white text-2xl font-bold">Identify Sick Fish</Text>
            </View>
          </View>
        </View>

        <ScrollView
          className="flex-1 rounded-t-3xl -mt-28 p-5 relative z-10"
          contentContainerStyle={{ paddingBottom: 150 }}
        >
          {/* Instructions Section */}
          <View className="mt-2 p-4 bg-white rounded-xl shadow-md">
            <Text className="text-blue-700 text-xl font-bold mb-3">
              <FontAwesome name="info-circle" size={20} color="#1c4ed8" /> How to Use
            </Text>
            <View className="bg-blue-100 p-4 rounded-lg shadow-sm">
              <Text className="text-gray-700 mb-2">
                • Capture or upload an image of your fish for analysis.
              </Text>
              <Text className="text-gray-700 mb-2">
                • Ensure good lighting and a clear view of the fish.
              </Text>
              <Text className="text-gray-600 text-base">
                We can help identify common fish diseases like fin rot, fungal infections, velvet
                disease, and more.
              </Text>
            </View>
          </View>

          {/* Buttons*/}
          <View className="flex-row justify-between w-full my-6">
            <TouchableOpacity
              onPress={pickImage}
              className="bg-blue-700 flex-1 mx-2 p-4 rounded-lg shadow-lg flex-row items-center justify-center"
            >
              <Ionicons name="image-outline" size={24} color="white" />
              <Text className="text-white text-center text-lg font-semibold ml-2">Select Image</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={captureImage}
              className="bg-blue-700 flex-1 mx-2 p-4 rounded-lg shadow-lg flex-row items-center justify-center"
            >
              <FontAwesome5 name="camera" size={20} color="white" />
              <Text className="text-white text-center text-lg font-semibold ml-2">Capture Image</Text>
            </TouchableOpacity>
          </View>

          {/* Image Selection*/}
          <View className="flex-1 justify-center items-center mt-4">
            {loading ? (
              <ActivityIndicator size="large" color="#1c4ed8" />
            ) : image ? (
              <Image
                source={{ uri: image }}
                style={{
                    width: "100%",
                    height: 200,
                    borderRadius: 10,
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.2,
                    shadowRadius: 3,
                    elevation: 5,
                }}
              />
            ) : (
              <Text className="text-gray-500 text-lg mb-5">No image selected</Text>
            )}

            {/* Submit Button */}
            {image && (
            <TouchableOpacity
                onPress={handleSubmit}
                className="bg-green-600 mt-6 p-4 rounded-lg shadow-lg w-full flex-row items-center justify-center"
            >
                <Ionicons name="checkmark-circle-outline" size={24} color="white" />
                <Text className="text-white text-center text-lg font-semibold ml-2">Submit</Text>
            </TouchableOpacity>
            )}
          </View>

          {/* Sample Image*/}
          <View className="mt-8 p-4 bg-white rounded-xl shadow-md">
            <Text className="text-blue-700 text-xl font-bold mb-3">
              <FontAwesome name="picture-o" size={20} color="#1c4ed8" /> Sample Image
            </Text>
            <Image
                source={{
                    uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Gold_fish1.jpg/440px-Gold_fish1.jpg',
                }}
                style={{
                    width: "100%",
                    height: 200,
                    borderRadius: 10,
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.2,
                    shadowRadius: 3,
                    elevation: 5,
                }}
            />
            <Text className="text-gray-600 text-sm mt-3 text-center">
              Use a similar well-lit and clear image for better results.
            </Text>
          </View>
        </ScrollView>

        {/* Waves Section */}
        <View className="absolute bottom-0 left-0 right-0 z-0">
          <Svg height="100" width="100%" viewBox="0 0 1440 320">
            <Defs>
              <LinearGradient id="gradientWave" x1="0%" y1="0%" x2="100%" y2="0%">
                <Stop offset="0%" stopColor="#1c4ed8" />
                <Stop offset="100%" stopColor="#0565c5" />
              </LinearGradient>
            </Defs>
            <Path
              fill="url(#gradientWave)"
              d="M0,64L60,74.7C120,85,240,107,360,122.7C480,139,600,149,720,138.7C840,128,960,96,1080,74.7C1200,53,1320,43,1380,37.3L1440,32L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"
            />
          </Svg>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default SelectImageScreen;
