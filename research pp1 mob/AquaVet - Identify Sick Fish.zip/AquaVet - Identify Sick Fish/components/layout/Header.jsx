import { View, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; // Import Ionicons for the arrow left icon

type HeaderProps = {
  showBackButton?: boolean; // Pass this prop to show the back button
};

const Header = ({ showBackButton }: HeaderProps) => {
  const navigation = useNavigation();

  return (
    <View className="w-full p-4 flex-row items-center bg-blue-500 shadow-md absolute top-0 left-0 right-0 z-10">
      {/* Left side - Back Button (only when needed) */}
      {showBackButton && (
        <TouchableOpacity onPress={() => navigation.goBack()} className="mr-4">
          {/* Arrow left icon */}
          <Ionicons name="arrow-back" size={20} color="white" />
        </TouchableOpacity>
      )}

      {/* Center - Logo (always centered) */}
      <View className="flex-1 items-center">
        <Image
          source={require('../../assets/images/logo.png')} // Your logo path here
          style={{ width: 40, height: 40, resizeMode: 'contain' }}
        />
      </View>
    </View>
  );
};

export default Header;
